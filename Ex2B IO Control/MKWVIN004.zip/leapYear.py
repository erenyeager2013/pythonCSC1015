#program to determine if a year is leap year or not
#Vincent T Mukwevo MKWVIN004
#28/02/2024

year = eval(input("Enter a year:\n"))

# to determine if year entered is a leap year
if (year%400 == 0) or ((year%4 == 0) and (year%100 != 0)):
    
    print(year , "is a leap year.")
else:
    print(year , "is not a leap year.")
        
 