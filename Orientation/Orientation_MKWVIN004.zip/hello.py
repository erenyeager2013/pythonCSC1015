# My very first progrm to Display Hello World on screen
# Name: Vincent Mukwevo
# Student Number: MKWVIN004
# Date: 16 February 2024

print("Hello World")
