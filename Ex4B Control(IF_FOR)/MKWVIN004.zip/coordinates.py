# A program to check if a set of six numbers is a pair of GPS cordinates.
# Mukwevo Vincent T MKWVIN004
# 03/06/2024

#obtaining input from the user
first_num = eval(input('Enter first number:\n'))
second_num = eval(input ('Enter second number:\n'))
third_num = eval(input('Enter third number:\n'))
fourth_num = eval(input('Enter fourth number:\n'))
fifth_num = eval(input('Enter fifth number:\n'))
sixth_num = eval(input('Enter sixth number:\n'))

# checking for validity of inputs
if not(first_num >= -90 and first_num <= 90):
     print ('Hmmm ... looks like 6 random numbers.')
else :
  if not(second_num >= 0 and  second_num <=59):
      print ('Hmmm ... looks like 6 random numbers.')
  else:    
     if not(third_num >= 0 and third_num <= 59):
        print ('Hmmm ... looks like 6 random numbers.')
     else:   
       if not(fourth_num >= -180 and fourth_num <= 180):
          print ('Hmmm ... looks like 6 random numbers.')
       else:
         if not(fifth_num >= 0 and  fifth_num <=59):
             print ('Hmmm ... looks like 6 random numbers.')
         else:    
            if (sixth_num >= 0 and sixth_num <= 59):
              print('WOW! Looks like geographic coordinates!')
            else :
               print ('Hmmm ... looks like 6 random numbers.')


