# Program to calculate energy given the mass and speed of light.
# Vincent T Mukwevo
# MKWVIN004
# 25/02/2024

mass = eval(input("Enter the value of m:"))
print()
light = eval(input("Enter the value of c:"))
print()
energy = (mass *(light**2))
print("The value of energy, E, is:", energy)