# progrom to determine if number is a perfect number
# MKWVIN004 Vincent T Mukwevo
# 03/04/2024

# obtaining input fro the user
numb = eval(input('Enter a number:'))
print('\nThe proper divisors of', numb, 'are:')

# finding the proper devisors of number
counter = 0
sum =0
while counter <= (numb/2) :
    
    counter = counter + 1
    if (numb% counter) == 0 :
        print(counter, end = ' ')
        sum = sum + (counter)
     
   
if (sum == numb):
       print('')
       print('')
       print (numb,'is a perfect number.') 
else :    
      print('')  
      print('')     
      print(numb,'is not a perfect number.')         