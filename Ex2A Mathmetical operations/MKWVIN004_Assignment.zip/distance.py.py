# Program to calculate and print distance d, given time t
# Vincent T Mukwevo MKWVIN004
# 29/02/2024

time = eval(input("Enter the travel time:\n"))
if (time >= 0) :
  distance = float((9.8 * (time*time))/2)
  print('The distance covered is %.2f.'%(distance))
else:
  print("\nThe travel time must be zero or more.")


            