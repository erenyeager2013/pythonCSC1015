# hat accepts a sentence as input and that outputs it as a comma-separated list of lowercase words with a full-stop at the end.

sente = input('Enter a sentence: \n')
sente = sente.lower()
# using the string replace function to create word list with comma's
print('The word list:',sente.replace(' ',', '), end='.')