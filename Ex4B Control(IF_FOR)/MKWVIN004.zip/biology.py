# a program that determines the type of an animal based on given parameters
# MKWVIN004 Vincent T Mukwevo
# 03/04/2024

# welcome paragraph
print(f'''
Welcome to the Biology Expert
-----------------------------
Answer the following questions by selecting from among the options.''')

# finding tpye of animal
skeleton = input('The skeleton is (internal/external)?\n')
if skeleton == 'internal' :
    fertilisation = input('The fertilisation of eggs occurs (within the body/outside the body)?\n')
    if fertilisation == 'within the body' :
        young_production = input('Young are produced by (waterproof eggs/live birth)?\n')
        if young_production == 'waterproof eggs':
            skin = input('The skin is covered by (scales/feathers)?\n')
            if skin == 'scales' :
                print ('Type of animal: Reptile')
            elif skin == 'feathers':
                print ('Type of animal: Bird')
        elif young_production == 'live birth'   :  
            print ('Type of animal: Mammal')
    elif fertilisation == 'outside the body' :
        liveplace = input('It lives (in water/near water)?\n') 
        if liveplace ==  'in water' :
            print('Type of animal: Fish')
        elif liveplace == 'near water' :
            print('Type of animal: Amphibian')
elif skeleton == 'external' :
    print('Type of animal: Arthropod')      
        