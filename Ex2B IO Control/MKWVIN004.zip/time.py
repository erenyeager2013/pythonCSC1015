# a program to check validity of time entered by user
# Vincent T Mukwevo MKWVIN004
# 27/02/2024

# obtaining input of the user
hours = int(input("Enter the hours:\n"))
minutes = int(input("Enter the minutes:\n"))
seconds = int(input("Enter the seconds:\n"))

# code to check if input is valid
if (hours <= 23) and (hours >= 0 ) :
    if (minutes <= 59) and (minutes >= 0) :
        if (seconds <= 59) and (seconds >= 0) :
            print("Your time is valid.")
        else :
            print("Your time is invalid.")
    else :
        print("Your time is invalid.")            
else :
    print("Your time is invalid.")
    