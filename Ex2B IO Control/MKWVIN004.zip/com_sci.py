# a program to print ASCII art using print function.
# Vincent Thabani Mukwevo MKWVIN004
# 27/02/2024

print('''
  ____ ____ ___ ____  _____ _   _ _   _ _
 / ___/ ___|_ _/ ___||  ___| | | | \ | | |
| |   \___ \| |\___ \| |_  | | | |  \| | |
| |___ ___) | | ___) |  _| | |_| | |\  |_|
 \____|____/___|____/|_|    \___/|_| \_(_)
''')